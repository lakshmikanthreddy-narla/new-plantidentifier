import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { plantData } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const prompt = `Based on this plant identification data, provide detailed, accurate information:

Plant Name: ${plantData.name}
Scientific Name: ${plantData.scientificName || 'Not provided'}
Wikipedia Description: ${plantData.wikiDescription || 'Not provided'}
Edible Parts: ${plantData.edibleParts || 'Not provided'}
Toxicity Info: ${plantData.toxicity || 'Not provided'}
Watering Info: ${plantData.watering || 'Not provided'}

Generate the following information specific to this plant:

1. HABITAT: Where does this plant naturally grow? (1-2 sentences)
2. CARE TIPS: Specific care instructions for this plant (2-3 sentences covering light, water, soil)
3. USES: What are the specific uses of this plant? Include medicinal, culinary, ornamental, or other uses (2-3 sentences)
4. DISADVANTAGES: What are the specific warnings, toxicity issues, or disadvantages of this plant? (2-3 sentences)
5. HOW TO GROW: Step-by-step growing instructions specific to this plant (3-4 sentences)
6. FUN FACT: One interesting fact about this plant (1 sentence)

Format your response as JSON with these exact keys: habitat, careTips, uses, disadvantages, howToGrow, facts`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: "You are a botanical expert. Provide accurate, detailed information about plants. Always respond with valid JSON only."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const aiResponse = data.choices[0].message.content;
    
    // Extract JSON from the response
    const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("Failed to extract JSON from AI response");
    }
    
    const enhancedDetails = JSON.parse(jsonMatch[0]);

    return new Response(JSON.stringify(enhancedDetails), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in enhance-plant-details:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
