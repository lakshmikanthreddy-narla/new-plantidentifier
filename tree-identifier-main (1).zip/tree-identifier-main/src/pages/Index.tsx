
import React, { useEffect } from "react";
import PlantUpload from "../components/PlantUpload";
import PlantResult from "../components/PlantResult";
import Navbar from "../components/Navbar";
import PageHeader from "../components/PageHeader";
import DecorativeBanner from "../components/DecorativeBanner";
import CallToAction from "../components/CallToAction";
import { usePlantIdentification } from "../hooks/usePlantIdentification";

const Index = () => {
  const apiKey = "yNApV2IHQafXkCoLcQYjqijnlhrtGWDkLxj9WrDAYRdlqfDT6t";
  const {
    imageUrl,
    plantInfo,
    loading,
    error,
    previewUrl,
    handleImageSelected,
    handleAddNewPlant
  } = usePlantIdentification(apiKey);

  // Resets preview if plantInfo is cleared
  useEffect(() => {
    if (!imageUrl && !loading) {
      // This effect is handled within the hook now
    }
  }, [imageUrl, loading]);

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-gradient-to-br from-slate-100 via-lime-50 to-green-200 px-2 py-0 font-inter flex flex-col pt-20">
        <DecorativeBanner />
        <PageHeader />
        <CallToAction />

        <main className="flex flex-col items-center flex-1 w-full">
          <div className="w-full max-w-3xl flex flex-col items-center gap-8 transition-all px-2">
            <PlantUpload
              onImageSelected={handleImageSelected}
              loading={loading}
              imagePreview={previewUrl}
            />
            <PlantResult
              info={plantInfo}
              imageUrl={imageUrl}
              loading={loading}
              error={error}
              previewUrl={previewUrl}
              onAddNew={handleAddNewPlant}
            />
          </div>
        </main>

        <footer className="mt-14 md:mt-28 flex flex-col items-center text-xs text-gray-500 relative z-10 pb-3">
          <div className="w-full flex justify-center">
            <span className="text-green-900/80 font-bold text-base px-3 py-2 rounded-lg bg-gradient-to-r from-emerald-100/30 to-lime-100/50 shadow-inner drop-shadow-md">
              
            </span>
          </div>
        </footer>
      </div>
    </>
  );
};

export default Index;
