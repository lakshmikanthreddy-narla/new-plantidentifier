
export type PlantInfo = {
  name: string;
  description: string;
  scientificName?: string;
  habitat?: string;
  careTips?: string;
  facts?: string;
  otherData?: string;
  uses?: string;
  disadvantages?: string;
  howToGrow?: string;
};
