
import React, { useRef, useState } from "react";
import { UploadCloud, Camera } from "lucide-react";
import CameraCapture from "./CameraCapture";

interface PlantUploadProps {
  onImageSelected: (file: File, url: string) => void;
  loading: boolean;
  imagePreview?: string | null;
}

const PlantUpload: React.FC<PlantUploadProps> = ({ onImageSelected, loading, imagePreview }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  const handleFile = (file: File) => {
    if (file && file.type.startsWith("image/")) {
      const url = URL.createObjectURL(file);
      onImageSelected(file, url);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (loading) return;
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handlePhotoTaken = (file: File, url: string) => {
    onImageSelected(file, url);
    setIsCameraOpen(false);
  };

  if (isCameraOpen) {
    return (
      <div className="w-full max-w-xl flex justify-center">
        <CameraCapture
          onPhotoTaken={handlePhotoTaken}
          onClose={() => setIsCameraOpen(false)}
        />
      </div>
    );
  }

  return (
    <div className="relative w-full max-w-xl">
      <div
        className={`bg-white/80 rounded-2xl shadow-2xl border-2 border-dashed border-green-400 px-10 py-14 flex flex-col items-center justify-center w-full transition-all min-h-[320px] hover:shadow-green-200 hover:border-green-600 cursor-pointer duration-200 group relative overflow-hidden ${
          loading ? "opacity-60 pointer-events-none blur-[1px]" : ""
        }`}
        onDrop={handleDrop}
        onDragOver={e => e.preventDefault()}
        role="button"
        tabIndex={0}
        aria-label="Click or drag to select a plant photo"
        style={{ cursor: loading ? "not-allowed" : "pointer" }}
        onClick={() => !loading && inputRef.current?.click()}
      >
        {/* Decorative backgrounds */}
        <div className="absolute inset-0 pointer-events-none z-0">
          <div className="absolute left-10 top-4 w-24 h-24 bg-lime-100 rounded-full blur-2xl opacity-50 animate-pulse" />
          <div className="absolute right-10 bottom-0 w-36 h-16 bg-green-200 rounded-full blur-[38px] opacity-30 animate-pulse" />
        </div>
        <UploadCloud className="w-14 h-14 text-green-500 mb-4 group-hover:scale-110 transition-transform z-10" />
        <p className="font-bold text-2xl mb-2 text-green-900 group-hover:text-green-700 z-10">
          {loading ? "Identifying..." : "Upload a plant photo"}
        </p>
        <p className="text-green-700 mb-2 group-hover:opacity-80 transition-opacity z-10">
          Click or drag &amp; drop your image
        </p>

        {/* Horizontal row of buttons: Upload and Camera */}
        <div className="flex flex-row items-center justify-center gap-5 my-6 z-10 w-full max-w-xs">
          {/* Upload button (label for file input) */}
          <label
            htmlFor="plant-upload-input"
            className={`flex items-center gap-2 bg-emerald-500 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-emerald-600 hover:scale-105 transition-all cursor-pointer disabled:bg-emerald-300 disabled:cursor-not-allowed
              ${loading ? "pointer-events-none opacity-60" : ""}
            `}
            style={{ userSelect: 'none' }}
            onClick={e => e.stopPropagation()}
          >
            <UploadCloud size={20} />
            Upload
            <input
              ref={inputRef}
              id="plant-upload-input"
              className="hidden"
              type="file"
              accept="image/*"
              onChange={handleChange}
              disabled={loading}
              tabIndex={-1}
            />
          </label>
          {/* Camera button */}
          <button
            type="button"
            onClick={e => {
              e.stopPropagation();
              if (!loading) setIsCameraOpen(true);
            }}
            disabled={loading}
            className="flex items-center gap-2 bg-emerald-500 text-white font-bold py-3 px-6 rounded-lg shadow-md hover:bg-emerald-600 hover:scale-105 transition-all disabled:bg-emerald-300 disabled:cursor-not-allowed"
          >
            <Camera size={20} />
            Camera
          </button>
        </div>

        <span className="text-xs text-green-800 font-medium mt-2 bg-lime-100 px-4 py-1 rounded shadow z-10">
          Supported: JPG, PNG, Max 5MB
        </span>
      </div>
    </div>
  );
};

export default PlantUpload;
