
import React, { useState, useRef, useEffect } from "react";
import { Camera, X } from "lucide-react";

interface CameraCaptureProps {
  onPhotoTaken: (file: File, url: string) => void;
  onClose: () => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onPhotoTaken, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const startCamera = async () => {
      let mediaStream: MediaStream;
      try {
        mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
        });
      } catch (err) {
        console.warn("Could not get environment camera, trying default.", err);
        try {
            mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
        } catch (fallbackErr) {
            console.error("Error accessing any camera:", fallbackErr);
            setError("Could not access camera. Please ensure permissions are granted in your browser settings.");
            return;
        }
      }
      
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    };

    startCamera();

    return () => {
      stream?.getTracks().forEach(track => track.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleTakePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext("2d");

      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        canvas.toBlob(blob => {
          if (blob) {
            const file = new File([blob], "capture.jpg", { type: "image/jpeg" });
            const url = URL.createObjectURL(file);
            onPhotoTaken(file, url);
          }
        }, "image/jpeg");
      }
    }
  };

  return (
    <div className="relative w-full max-w-xl bg-black rounded-2xl shadow-2xl overflow-hidden border-4 border-emerald-500 animate-fade-in">
      <canvas ref={canvasRef} className="hidden" />
      <video
        ref={videoRef}
        autoPlay
        playsInline
        className="w-full h-auto"
      />
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 text-white p-4">
          <p className="text-red-400 font-semibold text-center">{error}</p>
        </div>
      )}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-all z-10"
        aria-label="Close camera"
      >
        <X size={24} />
      </button>
      {!error && (
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent flex justify-center items-center">
          <button
            onClick={handleTakePhoto}
            className="p-4 rounded-full bg-white text-emerald-500 border-4 border-emerald-500 hover:bg-emerald-100 transition-all transform hover:scale-110"
            aria-label="Take photo"
          >
            <Camera size={32} />
          </button>
        </div>
      )}
    </div>
  );
};

export default CameraCapture;
