import React from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Button } from "./ui/button";
import { Plus } from "lucide-react";
import { PlantInfo } from "@/types/plant";

// Props extended: previewUrl for preview before/while loading, onAddNew for reset functionality
interface PlantResultProps {
  info: PlantInfo | null;
  imageUrl: string | null;
  loading: boolean;
  error: string | null;
  previewUrl?: string | null;
  onAddNew?: () => void;
}

const PlantResult: React.FC<PlantResultProps> = ({ info, imageUrl, loading, error, previewUrl, onAddNew }) => {
  // Show attractive image preview before analysis result
  if (!info && (previewUrl || loading)) {
    return (
      <div className="flex flex-col items-center mt-10 w-full max-w-xl animate-fade-in">
        <div className="relative rounded-2xl bg-gradient-to-br from-green-100 via-emerald-100 to-lime-100 p-1 shadow-lg border border-green-100">
          <img
            src={previewUrl || ""}
            alt="Uploading..."
            className="w-64 h-52 object-cover object-center rounded-xl shadow-md border-2 border-emerald-100"
            style={{ opacity: loading ? 0.65 : 1, filter: loading ? "blur(1px)" : "none" }}
          />
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center z-20">
              <span className="bg-white/80 px-4 py-2 rounded text-green-700 font-bold shadow animate-pulse text-lg">Analyzing...</span>
            </div>
          )}
        </div>
        <p className="mt-5 text-green-800 text-base font-semibold animate-fade-in">
          {loading ? "Analyzing your plant photo, please wait..." : (
            <>
              Ready to analyze your plant!&nbsp;
              <span className="text-emerald-600">Click Upload again or wait for the result.</span>
            </>
          )}
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center mt-10 animate-pulse w-full max-w-xl">
        <div className="rounded-2xl bg-gradient-to-br from-green-100 via-emerald-100 to-lime-100 h-52 w-64 mb-6 shadow-inner"></div>
        <div className="h-5 w-40 bg-green-200 rounded mb-3" />
        <div className="h-4 w-72 bg-emerald-100 rounded mb-1" />
        <div className="h-4 w-48 bg-emerald-100 rounded" />
        <p className="mt-4 text-sm text-green-400 animate-fade-in">Analyzing your plant photo...</p>
      </div>
    );
  }
  if (error) {
    return (
      <div className="text-center mt-10 text-red-600 font-semibold animate-fade-in bg-red-50 rounded-lg px-4 py-3 w-full max-w-md shadow">
        {error}
      </div>
    );
  }
  if (!info || !imageUrl) return null;
  return (
    <div className="w-full max-w-xl flex flex-col items-center mt-8 animate-fade-in">
      <div className="relative group rounded-2xl bg-gradient-to-br from-lime-100 via-white to-green-50 p-1 shadow-lg border border-green-100 transition-transform hover:scale-105 hover:shadow-2xl duration-300">
        <img
          src={imageUrl}
          alt={`Plant: ${info.name}`}
          className="w-64 h-52 object-cover object-center rounded-xl shadow-md mb-3 border-2 border-emerald-100"
        />
        <div className="absolute top-2 right-2 pointer-events-none opacity-50 group-hover:opacity-80 transition">
          <span className="bg-white/80 px-2 py-0.5 rounded text-xs text-green-700 font-medium shadow-sm">
            Identified
          </span>
        </div>
      </div>
      
      {/* Add New Plant Button */}
      {onAddNew && (
        <Button
          onClick={onAddNew}
          className="mt-4 mb-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 py-2 rounded-lg shadow-md transition-all hover:scale-105"
        >
          <Plus size={20} className="mr-2" />
          Add New Plant
        </Button>
      )}

      <h2 className="text-3xl font-extrabold text-emerald-800 mb-2 mt-4 font-inter drop-shadow animate-scale-in">{info.name}</h2>
      {/* Description */}
      {!!info.description && (
        <div className="bg-white rounded-xl shadow-md px-8 py-6 text-gray-800 max-w-xl w-full border border-emerald-100 mt-2 mb-3 animate-fade-in text-base leading-relaxed">
          <span className="font-semibold text-green-800">Description: </span>
          {info.description}
        </div>
      )}
      {/* Table of information (under description) */}
      <div className="w-full max-w-xl mt-2 mb-3">
        <Table className="rounded-xl overflow-hidden shadow border border-green-200 bg-white/80">
          <TableHeader>
            <TableRow className="bg-emerald-50 border-b border-green-200">
              <TableHead className="w-1/3 text-emerald-900 text-lg font-bold">Attribute</TableHead>
              <TableHead className="text-green-800 text-lg font-semibold">Details</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium text-green-700">Scientific Name</TableCell>
              <TableCell>{info.scientificName || <span className="italic text-gray-400">—</span>}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium text-green-700">Habitat</TableCell>
              <TableCell>{info.habitat || <span className="italic text-gray-400">—</span>}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium text-green-700">Care Tips</TableCell>
              <TableCell>{info.careTips || <span className="italic text-gray-400">—</span>}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium text-green-700">Uses</TableCell>
              <TableCell>{info.uses || <span className="italic text-gray-400">—</span>}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium text-green-700">Disadvantages</TableCell>
              <TableCell>{info.disadvantages || <span className="italic text-gray-400">—</span>}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium text-green-700">How to Grow</TableCell>
              <TableCell>{info.howToGrow || <span className="italic text-gray-400">—</span>}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium text-green-700">Facts</TableCell>
              <TableCell>{info.facts || <span className="italic text-gray-400">—</span>}</TableCell>
            </TableRow>
            {!!info.otherData && (
              <TableRow>
                <TableCell className="font-medium text-green-700">Other</TableCell>
                <TableCell>
                  <span className="text-gray-700">{info.otherData}</span>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      {/* Fun fact or extra info below table */}
      {info.facts && (
        <div className="mt-3 text-green-900 font-medium text-md italic bg-emerald-50 rounded px-5 py-3 shadow animate-fade-in">
          🌟 <span className="text-emerald-700 font-semibold">Fun Fact: </span>{info.facts}
        </div>
      )}
    </div>
  );
};

export default PlantResult;
