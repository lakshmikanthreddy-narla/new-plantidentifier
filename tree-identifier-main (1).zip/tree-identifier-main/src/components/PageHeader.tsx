
import React from "react";

const PageHeader: React.FC = () => {
  return (
    <header className="flex flex-col items-center mb-6 px-3 pt-20 pb-4 relative z-10">
      <h1 className="text-5xl md:text-6xl font-extrabold mb-2 text-green-900 tracking-tight drop-shadow-md font-inter bg-gradient-to-r from-green-700 via-emerald-500 to-lime-500 bg-clip-text text-transparent animate-fade-in">
        🌱 Plant Vision
      </h1>
      <p className="text-2xl md:text-3xl text-green-800 font-semibold max-w-2xl text-center mb-3 drop-shadow-sm z-10 animate-fade-in">
        Discover, identify, and learn about plants instantly with AI
      </p>
    </header>
  );
};

export default PageHeader;
