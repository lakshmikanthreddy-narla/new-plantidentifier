
import React from "react";

const CallToAction: React.FC = () => {
  return (
    <>
      <section className="flex flex-col items-center py-1 mb-2 z-20">
        <div className="text-lg md:text-xl text-emerald-800 font-medium bg-lime-100/50 px-6 py-3 rounded-xl shadow-md mb-1 animate-fade-in border border-green-200 max-w-2xl w-full text-center">
          Simply upload a picture of any plant and instantly get detailed information, care tips, and curious facts — perfect for home gardeners and nature lovers!
        </div>
      </section>

      <div className="flex flex-row justify-center items-center space-x-5 mt-2 mb-2 animate-fade-in">
        <div className="border border-lime-400 bg-white rounded-xl px-4 py-2 shadow transition hover:scale-105 hover:bg-lime-50 text-green-800 font-semibold">No sign up required</div>
        <div className="border border-emerald-400 bg-white rounded-xl px-4 py-2 shadow transition hover:scale-105 hover:bg-emerald-50 text-emerald-700 font-semibold">Free & Instant</div>
      </div>
    </>
  );
};

export default CallToAction;
