
import React from "react";

const DecorativeBanner: React.FC = () => {
  return (
    <div className="absolute w-full left-0 top-0 h-64 pointer-events-none -z-10">
      <div className="bg-gradient-to-br from-green-200/60 via-lime-100 to-emerald-100 h-full w-full blur-2xl rounded-b-[60px] shadow-2xl"></div>
      <div className="absolute left-14 top-12 w-40 h-40 rounded-full bg-lime-200/60 blur-3xl opacity-60 animate-pulse"></div>
      <div className="absolute right-16 top-28 w-28 h-28 rounded-full bg-emerald-200/40 blur-2xl opacity-90 animate-pulse"></div>
    </div>
  );
};

export default DecorativeBanner;
