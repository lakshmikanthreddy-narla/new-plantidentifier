
import React from "react";
import { Home, Navigation, Info } from "lucide-react";

const navItems = [
  {
    label: "Home",
    icon: Home,
    href: "/",
  },
  {
    label: "About",
    icon: Info,
    href: "#about",
  },
  {
    label: "Navigate",
    icon: Navigation,
    href: "#navigate",
  },
];

const Navbar: React.FC = () => (
  <nav className="w-full bg-white/80 shadow-lg rounded-b-2xl border-b-2 border-lime-200 px-3 py-3 fixed top-0 left-0 z-50 animate-fade-in transition-all">
    <div className="mx-auto max-w-5xl flex items-center justify-between">
      <span className="text-2xl font-extrabold text-green-800 flex items-center space-x-2 tracking-tight">
        <span role="img" aria-label="Logo">🌱</span>
        <span>Plant Vision</span>
      </span>
      <ul className="flex space-x-6 md:space-x-10 items-center">
        {navItems.map(({ label, icon: Icon, href }) => (
          <li key={label}>
            <a
              href={href}
              className="flex items-center space-x-2 px-3 py-1 rounded hover:bg-emerald-50 transition-colors text-emerald-700 text-lg font-semibold hover:scale-105"
              aria-label={label}
            >
              <Icon size={22} className="mr-1 text-green-600" />
              <span className="hidden md:inline">{label}</span>
            </a>
          </li>
        ))}
      </ul>
    </div>
  </nav>
);

export default Navbar;
