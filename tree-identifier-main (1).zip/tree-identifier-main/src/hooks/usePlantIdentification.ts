
import { useState } from "react";
import { PlantInfo } from "@/types/plant";
import { identifyPlant } from "@/services/plantIdentification";
import { toast } from "@/hooks/use-toast";

export const usePlantIdentification = (apiKey: string) => {
  const [image, setImage] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [plantInfo, setPlantInfo] = useState<PlantInfo | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleImageSelected = async (file: File, url: string) => {
    setImage(file);
    setImageUrl(url);
    setPreviewUrl(url);
    setPlantInfo(null);
    setError(null);
    setLoading(true);
    try {
      const result = await identifyPlant(file, apiKey);
      setPlantInfo(result);
    } catch (err: any) {
      setError(err?.message ?? "Something went wrong.");
      toast({ title: "Error", description: err?.message ?? "Identification failed." });
    }
    setLoading(false);
  };

  const handleAddNewPlant = () => {
    setImage(null);
    setImageUrl(null);
    setPreviewUrl(null);
    setPlantInfo(null);
    setError(null);
    setLoading(false);
  };

  return {
    image,
    imageUrl,
    plantInfo,
    loading,
    error,
    previewUrl,
    handleImageSelected,
    handleAddNewPlant
  };
};
