
import { PlantInfo } from "@/types/plant";
import { supabase } from "@/integrations/supabase/client";

export async function identifyPlant(image: File, apiKey: string): Promise<PlantInfo> {
  // Convert the image file to base64 string
  const getBase64 = (file: File) =>
    new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve((e.target?.result as string).split(",")[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const base64 = await getBase64(image);

  // Plant.id API request
  const body = {
    images: [base64],
    modifiers: ["crops_fast", "similar_images"],
    plant_language: "en",
    plant_details: [
      "common_names",
      "taxonomy",
      "url",
      "wiki_description",
      "wiki_image",
      "edible_parts",
      "propagation_methods",
      "watering",
      "toxicity"
    ]
  };

  const res = await fetch(
    "https://api.plant.id/v2/identify",
    {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Api-Key": apiKey
      },
      body: JSON.stringify(body)
    }
  );
  
  if (!res.ok) {
    throw new Error("Identification failed. Check API key & usage quota.");
  }

  const data = await res.json();

  if (!data.suggestions || data.suggestions.length === 0) {
    throw new Error("Sorry, unable to recognize this plant.");
  }

  // Get the top suggestion
  const suggestion = data.suggestions[0];
  const name = suggestion.plant_name || "Unknown plant";
  const scientificName = suggestion.plant_details?.scientific_name || "";
  const description = suggestion.plant_details?.wiki_description?.value || 
                     `A ${name} with ${(suggestion.probability * 100).toFixed(1)}% confidence match.`;
  
  // Prepare data for AI enhancement
  const plantData = {
    name,
    scientificName,
    wikiDescription: suggestion.plant_details?.wiki_description?.value || "",
    edibleParts: suggestion.plant_details?.edible_parts?.join(", ") || "",
    toxicity: suggestion.plant_details?.toxicity || "",
    watering: suggestion.plant_details?.watering || "",
  };

  // Call edge function to enhance details with AI
  try {
    const { data: enhancedData, error } = await supabase.functions.invoke('enhance-plant-details', {
      body: { plantData }
    });

    if (error) throw error;

    return {
      name,
      description,
      scientificName,
      habitat: enhancedData.habitat || "Various habitats",
      careTips: enhancedData.careTips || "Research specific care requirements for best results.",
      facts: enhancedData.facts || `Identification confidence: ${(suggestion.probability * 100).toFixed(1)}%`,
      otherData: "",
      uses: enhancedData.uses || "Research specific applications for this plant.",
      disadvantages: enhancedData.disadvantages || "No specific disadvantages found.",
      howToGrow: enhancedData.howToGrow || "Consult gardening resources for growing instructions."
    };
  } catch (error) {
    console.error("Error enhancing plant details:", error);
    // Fallback to basic info if AI enhancement fails
    return {
      name,
      description,
      scientificName,
      habitat: "Various habitats",
      careTips: "Research specific care requirements for best results.",
      facts: `Identification confidence: ${(suggestion.probability * 100).toFixed(1)}%`,
      otherData: "",
      uses: "Research specific applications (culinary, medicinal, ornamental) for this plant.",
      disadvantages: "Verify toxicity and handling for this plant.",
      howToGrow: "Consult gardening resources for specific growing instructions."
    };
  }
}
